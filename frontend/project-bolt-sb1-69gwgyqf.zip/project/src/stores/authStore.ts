import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';

export type UserRole = 'admin' | 'staff';

interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  businessId: string;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string, businessName: string) => Promise<void>;
  logout: () => void;
  forgotPassword: (email: string) => Promise<void>;
}

// Mock user data for demo purposes
const mockUser: User = {
  id: '1',
  name: 'John Doe',
  email: 'john@example.com',
  role: 'admin',
  businessId: 'business-1',
};

export const useAuthStore = create<AuthState>()(
  devtools(
    persist(
      (set) => ({
        user: null,
        isAuthenticated: false,
        
        login: async (email: string, password: string) => {
          // This would be an API call in a real application
          if (email && password) {
            // Simulate API delay
            await new Promise((resolve) => setTimeout(resolve, 1000));
            
            set({
              user: mockUser,
              isAuthenticated: true,
            });
          }
        },
        
        register: async (name: string, email: string, password: string, businessName: string) => {
          // This would be an API call in a real application
          if (name && email && password && businessName) {
            // Simulate API delay
            await new Promise((resolve) => setTimeout(resolve, 1000));
            
            set({
              user: {
                ...mockUser,
                name,
                email,
              },
              isAuthenticated: true,
            });
          }
        },
        
        logout: () => {
          set({
            user: null,
            isAuthenticated: false,
          });
        },
        
        forgotPassword: async (email: string) => {
          // This would be an API call in a real application
          if (email) {
            // Simulate API delay
            await new Promise((resolve) => setTimeout(resolve, 1000));
            
            // In a real app, this would trigger an email with reset instructions
            console.log('Password reset email sent to:', email);
          }
        },
      }),
      {
        name: 'auth-storage',
      }
    )
  )
);