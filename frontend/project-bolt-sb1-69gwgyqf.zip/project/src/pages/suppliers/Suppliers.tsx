import React from 'react';
import { Card } from '../../components/ui/Card';

export default function Suppliers() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Suppliers</h1>
      
      <Card className="overflow-hidden">
        <div className="p-6">
          <p className="text-gray-600">Suppliers management page content will go here.</p>
        </div>
      </Card>
    </div>
  );
}