import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, ArrowLeft } from 'lucide-react';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';
import { useAuthStore } from '../../stores/authStore';

const ForgotPassword: React.FC = () => {
  const { forgotPassword } = useAuthStore();
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess(false);
    
    if (!email) {
      setError('Please enter your email address');
      return;
    }
    
    try {
      setIsLoading(true);
      await forgotPassword(email);
      setSuccess(true);
    } catch (err) {
      setError('Failed to send password reset link. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <Link to="/login" className="flex items-center text-sm text-primary-600 hover:text-primary-500">
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to login
        </Link>
      </div>
      
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900">Reset your password</h2>
        <p className="mt-2 text-sm text-gray-600">
          Enter your email and we'll send you a link to reset your password.
        </p>
      </div>
      
      {success ? (
        <div className="bg-success-50 text-success-700 p-4 rounded-md">
          <p className="text-sm font-medium">Password reset link sent!</p>
          <p className="text-sm mt-1">
            Check your email for instructions to reset your password. If you don't see it, check your spam folder.
          </p>
          <div className="mt-4">
            <Link to="/login" className="text-sm font-medium text-primary-600 hover:text-primary-500">
              Return to login
            </Link>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="bg-error-50 text-error-700 p-3 rounded-md text-sm">
              {error}
            </div>
          )}
          
          <Input
            label="Email Address"
            type="email"
            id="email"
            leftIcon={<Mail className="h-5 w-5" />}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
            required
          />
          
          <Button
            type="submit"
            className="w-full"
            isLoading={isLoading}
            loadingText="Sending link..."
          >
            Send Reset Link
          </Button>
        </form>
      )}
    </div>
  );
};

export default ForgotPassword;