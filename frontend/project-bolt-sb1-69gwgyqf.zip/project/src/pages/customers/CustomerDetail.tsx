import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  User, 
  Phone, 
  Mail, 
  MapPin,
  ArrowUpRight,
  ArrowDownRight,
  FileText,
  Send,
  Edit,
  Plus
} from 'lucide-react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Badge from '../../components/ui/Badge';
import { formatCurrency, formatDate } from '../../utils/formatters';

// Mock customer data
const customer = {
  id: '1',
  name: 'Acme Corporation',
  contact: 'John Smith',
  phone: '+91 98765 43210',
  email: 'john@acmecorp.com',
  address: '123 Business Park, Phase 2, Mumbai, Maharashtra 400001',
  gstin: '27AADCB2230M1Z3',
  pan: 'AADCB2230M',
  balance: 28500,
  balanceType: 'receivable',
  notes: 'Key account - 10% discount on bulk orders',
  transactions: [
    {
      id: 'txn-001',
      date: new Date('2023-06-25'),
      description: 'Payment received',
      amount: 15000,
      type: 'credit',
      reference: 'INV-2023-042',
    },
    {
      id: 'txn-002',
      date: new Date('2023-06-15'),
      description: 'Invoice #INV-2023-042',
      amount: 35000,
      type: 'debit',
      reference: 'INV-2023-042',
    },
    {
      id: 'txn-003',
      date: new Date('2023-05-28'),
      description: 'Payment received',
      amount: 22000,
      type: 'credit',
      reference: 'INV-2023-035',
    },
    {
      id: 'txn-004',
      date: new Date('2023-05-10'),
      description: 'Invoice #INV-2023-035',
      amount: 22000,
      type: 'debit',
      reference: 'INV-2023-035',
    },
    {
      id: 'txn-005',
      date: new Date('2023-04-30'),
      description: 'Payment received',
      amount: 18500,
      type: 'credit',
      reference: 'INV-2023-027',
    },
  ],
  invoices: [
    {
      id: 'INV-2023-042',
      date: new Date('2023-06-15'),
      dueDate: new Date('2023-07-15'),
      amount: 35000,
      status: 'partially_paid',
      balance: 20000,
    },
    {
      id: 'INV-2023-035',
      date: new Date('2023-05-10'),
      dueDate: new Date('2023-06-10'),
      amount: 22000,
      status: 'paid',
      balance: 0,
    },
    {
      id: 'INV-2023-027',
      date: new Date('2023-04-22'),
      dueDate: new Date('2023-05-22'),
      amount: 18500,
      status: 'paid',
      balance: 0,
    },
  ],
};

const CustomerDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  
  // In a real app, fetch customer data based on id
  
  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center gap-4">
        <Link to="/customers" className="text-gray-500 hover:text-gray-700">
          <ArrowLeft className="h-5 w-5" />
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{customer.name}</h1>
          <p className="text-gray-600">Customer Profile</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column */}
        <div className="space-y-6">
          {/* Customer Info Card */}
          <Card>
            <div className="flex justify-between items-start mb-6">
              <h2 className="text-lg font-semibold text-gray-900">Customer Information</h2>
              <Button
                variant="outline"
                size="sm"
                leftIcon={<Edit className="h-4 w-4" />}
                onClick={() => {}}
              >
                Edit
              </Button>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <User className="h-5 w-5 text-gray-400 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-500">Contact Person</p>
                  <p className="text-gray-900">{customer.contact}</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <Phone className="h-5 w-5 text-gray-400 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-500">Phone</p>
                  <p className="text-gray-900">{customer.phone}</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <Mail className="h-5 w-5 text-gray-400 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-500">Email</p>
                  <p className="text-gray-900">{customer.email}</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-gray-400 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-500">Address</p>
                  <p className="text-gray-900">{customer.address}</p>
                </div>
              </div>
              
              <div className="pt-3 border-t border-gray-200">
                <div className="flex justify-between mb-2">
                  <p className="text-sm text-gray-500">GSTIN</p>
                  <p className="text-sm text-gray-900">{customer.gstin}</p>
                </div>
                <div className="flex justify-between">
                  <p className="text-sm text-gray-500">PAN</p>
                  <p className="text-sm text-gray-900">{customer.pan}</p>
                </div>
              </div>
              
              {customer.notes && (
                <div className="pt-3 border-t border-gray-200">
                  <p className="text-sm text-gray-500 mb-1">Notes</p>
                  <p className="text-sm text-gray-700">{customer.notes}</p>
                </div>
              )}
            </div>
          </Card>
          
          {/* Balance Card */}
          <Card>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Account Balance</h2>
            
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg mb-4">
              <p className="text-gray-700">Current Balance</p>
              <div className="flex items-center">
                {customer.balanceType === 'receivable' ? (
                  <>
                    <ArrowUpRight className="h-4 w-4 text-success-500 mr-1" />
                    <span className="text-success-700 font-medium">
                      {formatCurrency(customer.balance)}
                    </span>
                  </>
                ) : (
                  <>
                    <ArrowDownRight className="h-4 w-4 text-error-500 mr-1" />
                    <span className="text-error-700 font-medium">
                      {formatCurrency(customer.balance)}
                    </span>
                  </>
                )}
              </div>
            </div>
            
            <div className="space-y-3">
              <Button
                variant="outline"
                className="w-full"
                leftIcon={<Plus className="h-4 w-4" />}
                onClick={() => {}}
              >
                Add Transaction
              </Button>
              
              <Button
                variant="outline"
                className="w-full"
                leftIcon={<FileText className="h-4 w-4" />}
                onClick={() => {}}
              >
                Create Invoice
              </Button>
              
              <Button
                variant="outline"
                className="w-full"
                leftIcon={<Send className="h-4 w-4" />}
                onClick={() => {}}
              >
                Send Statement
              </Button>
            </div>
          </Card>
        </div>
        
        {/* Right column - Transaction history */}
        <div className="lg:col-span-2 space-y-6">
          {/* Invoices */}
          <Card>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Invoices</h2>
              <Button
                size="sm"
                leftIcon={<FileText className="h-4 w-4" />}
                onClick={() => {}}
              >
                New Invoice
              </Button>
            </div>
            
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead>
                  <tr>
                    <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Invoice #
                    </th>
                    <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date
                    </th>
                    <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Due Date
                    </th>
                    <th className="px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Amount
                    </th>
                    <th className="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-100">
                  {customer.invoices.map((invoice) => (
                    <tr key={invoice.id} className="hover:bg-gray-50">
                      <td className="px-3 py-3 whitespace-nowrap text-sm font-medium text-primary-600">
                        <Link to={`/invoices/${invoice.id}`}>{invoice.id}</Link>
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-gray-500">
                        {formatDate(invoice.date)}
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-gray-500">
                        {formatDate(invoice.dueDate)}
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-right font-medium">
                        {formatCurrency(invoice.amount)}
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-center">
                        {invoice.status === 'paid' ? (
                          <Badge variant="success">Paid</Badge>
                        ) : invoice.status === 'partially_paid' ? (
                          <Badge variant="warning">Partially Paid</Badge>
                        ) : (
                          <Badge variant="error">Unpaid</Badge>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
          
          {/* Transaction History */}
          <Card>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Transaction History</h2>
              <div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {}}
                >
                  Export
                </Button>
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead>
                  <tr>
                    <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date
                    </th>
                    <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Description
                    </th>
                    <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Reference
                    </th>
                    <th className="px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Amount
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-100">
                  {customer.transactions.map((transaction) => (
                    <tr key={transaction.id} className="hover:bg-gray-50">
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-gray-500">
                        {formatDate(transaction.date)}
                      </td>
                      <td className="px-3 py-3 text-sm text-gray-900">
                        {transaction.description}
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-primary-600">
                        <Link to={`/invoices/${transaction.reference}`}>
                          {transaction.reference}
                        </Link>
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm font-medium text-right">
                        <div className="flex items-center justify-end">
                          {transaction.type === 'credit' ? (
                            <>
                              <ArrowUpRight className="h-4 w-4 text-success-500 mr-1" />
                              <span className="text-success-700">
                                {formatCurrency(transaction.amount)}
                              </span>
                            </>
                          ) : (
                            <>
                              <ArrowDownRight className="h-4 w-4 text-error-500 mr-1" />
                              <span className="text-error-700">
                                {formatCurrency(transaction.amount)}
                              </span>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default CustomerDetail;