import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Plus, 
  Search, 
  ArrowUpRight, 
  ArrowDownRight, 
  MoreVertical,
  FileText,
  Send,
  Trash2
} from 'lucide-react';
import Button from '../../components/ui/Button';
import Card from '../../components/ui/Card';
import { formatCurrency } from '../../utils/formatters';

// Mock customer data
const customers = [
  {
    id: '1',
    name: 'Acme Corporation',
    contact: 'John Smith',
    phone: '+91 98765 43210',
    email: 'john@acmecorp.com',
    balance: 28500,
    balanceType: 'receivable',
  },
  {
    id: '2',
    name: 'TechSolutions Inc',
    contact: 'Sarah Johnson',
    phone: '+91 87654 32109',
    email: 'sarah@techsolutions.com',
    balance: 42000,
    balanceType: 'receivable',
  },
  {
    id: '3',
    name: 'Global Traders',
    contact: 'Rajesh Kumar',
    phone: '+91 76543 21098',
    email: 'rajesh@globaltraders.com',
    balance: 0,
    balanceType: 'none',
  },
  {
    id: '4',
    name: 'Metro Retail',
    contact: 'Priya Sharma',
    phone: '+91 65432 10987',
    email: 'priya@metroretail.com',
    balance: 15000,
    balanceType: 'receivable',
  },
  {
    id: '5',
    name: 'Sunshine Enterprises',
    contact: 'David Wilson',
    phone: '+91 54321 09876',
    email: 'david@sunshine.com',
    balance: 3500,
    balanceType: 'payable',
  },
];

const Customers: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  
  // Filter customers based on search term
  const filteredCustomers = customers.filter(
    (customer) =>
      customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.contact.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.email.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const toggleDropdown = (customerId: string) => {
    setActiveDropdown(activeDropdown === customerId ? null : customerId);
  };
  
  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Customers</h1>
          <p className="text-gray-600">Manage your customer accounts and balances</p>
        </div>
        
        <Button 
          leftIcon={<Plus className="h-4 w-4" />}
          onClick={() => {}}
        >
          Add Customer
        </Button>
      </div>
      
      <Card>
        <div className="flex flex-col sm:flex-row justify-between gap-4 mb-4">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              className="input pl-10 w-full"
              placeholder="Search customers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex gap-2">
            <Button 
              variant="outline"
              onClick={() => {}}
            >
              Filter
            </Button>
            <Button 
              variant="outline"
              onClick={() => {}}
            >
              Export
            </Button>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead>
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Customer
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Contact
                </th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Balance
                </th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-100">
              {filteredCustomers.length > 0 ? (
                filteredCustomers.map((customer) => (
                  <tr key={customer.id} className="hover:bg-gray-50">
                    <td className="px-4 py-4">
                      <Link to={`/customers/${customer.id}`} className="block">
                        <p className="font-medium text-gray-900">{customer.name}</p>
                        <p className="text-sm text-gray-500">{customer.email}</p>
                      </Link>
                    </td>
                    <td className="px-4 py-4">
                      <p className="text-sm text-gray-900">{customer.contact}</p>
                      <p className="text-sm text-gray-500">{customer.phone}</p>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-right">
                      {customer.balance > 0 ? (
                        <div className="flex items-center justify-end">
                          {customer.balanceType === 'receivable' ? (
                            <>
                              <ArrowUpRight className="h-4 w-4 text-success-500 mr-1" />
                              <span className="text-success-700">
                                {formatCurrency(customer.balance)}
                              </span>
                            </>
                          ) : (
                            <>
                              <ArrowDownRight className="h-4 w-4 text-error-500 mr-1" />
                              <span className="text-error-700">
                                {formatCurrency(customer.balance)}
                              </span>
                            </>
                          )}
                        </div>
                      ) : (
                        <span className="text-gray-500">No Balance</span>
                      )}
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap text-sm text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          leftIcon={<FileText className="h-4 w-4" />}
                          onClick={() => {}}
                        >
                          Invoice
                        </Button>
                        
                        <div className="relative">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => toggleDropdown(customer.id)}
                            aria-label="More options"
                          >
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                          
                          {activeDropdown === customer.id && (
                            <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg z-10 py-1 ring-1 ring-black ring-opacity-5">
                              <button
                                className="flex w-full items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                onClick={() => {}}
                              >
                                <Send className="h-4 w-4 mr-2" />
                                Send Statement
                              </button>
                              <button
                                className="flex w-full items-center px-4 py-2 text-sm text-error-600 hover:bg-gray-100"
                                onClick={() => {}}
                              >
                                <Trash2 className="h-4 w-4 mr-2" />
                                Delete
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="px-4 py-6 text-center text-gray-500">
                    No customers found matching your search.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        <div className="flex justify-between items-center mt-4 pt-3 border-t border-gray-200">
          <p className="text-sm text-gray-600">
            Showing {filteredCustomers.length} of {customers.length} customers
          </p>
          
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={true}
            >
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={true}
            >
              Next
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default Customers;